from django.contrib import admin
from .models import *
from django.contrib import admin

admin.site.register(Cidade)
admin.site.register(Usuarios)
admin.site.register(Pais)
admin.site.register(Viagens)
admin.site.register(Hotel)

